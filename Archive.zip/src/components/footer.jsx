import React from 'react';

const Footer = () => {
    return (
        <div className="">
        <p className="my-10  text-center text-neutral-300">
        &copy; 2024 Sulcrus. Made for Paragon Test.
        </p>
        </div>
    );
};

export default Footer;